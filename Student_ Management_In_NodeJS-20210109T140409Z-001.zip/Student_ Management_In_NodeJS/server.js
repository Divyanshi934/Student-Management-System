require('dotenv').config();

const nodemailer = require('nodemailer');
const log = console.log;

// Step 1
let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL || 'abc@gmail.com', //your mail ID
        pass: process.env.PASSWORD || '12345678' 
    }
});

// Step 2
let mailOptions = {
    from: 'abc@gmail.com', //your mail ID
    to: 'efg@gmail.com ,xyz@gmail.com ', //Receiver's mail ID
    cc: 'xyz@gmail.com ',                             //Receiver Mail ID
    subject: 'Sending Mail via NodeJS',
    text: 'Its working!!! I m sending u this mail via Nodejs not by gmail :)',
    attachments: [
        {filename: 'DBMS Swayam.jpg,', path: './public/images/DBMS Swayam.jpg'}
    ]
};

// Step 3
transporter.sendMail(mailOptions, (err, data) => {
    if (err) {
        console.log('Error occurs',err);
    }
    console.log('Email sent!!!');
});