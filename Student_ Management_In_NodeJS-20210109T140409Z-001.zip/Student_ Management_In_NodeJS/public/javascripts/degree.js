$(document).ready(function(){
    $.get('/add/fetchdegree',{ajax:true},function(data){
     $.each(data,function(index,item){
       
      $('#degree').append($('<option>').text(item.degree).val(item.degreeid))
     })
    })
    
    $('#degree').change(function(){
    
        $.get('/add/fetchbranch',{ajax:true,bid:$('#degree').val()},function(data){
            $('#branchname').empty()
            $('#branchname').append($('<option>').text('-Branch-'))
            $.each(data,function(index,item){
              
             $('#branchname').append($('<option>').text(item.branchname).val(item.branchlistid))
            })
           })
           
    
    })
    
    
    
    })