$(document).ready(function(){
    $.get('/add/fetchtask',{ajax:true},function(data){
     $.each(data,function(index,item){
       
      $('#task').append($('<option>').text(item.task).val(item.taskid))
     })
    })
    
    $('#task').change(function(){
    
        $.get('/add/fetchsubmit',{ajax:true,tid:$('#task').val()},function(data){
            $('#submitname').empty()
            $('#submitname').append($('<option>').text('-Project-'))
            $.each(data,function(index,item){
              
             $('#submitname').append($('<option>').text(item.submitname).val(item.submitlistid))
            })
           })
           
    
    })
    
    
    
    })