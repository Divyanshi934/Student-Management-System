var express = require('express');
var router = express.Router();
var pool=require('./pool.js')

router.get('/studentlogin', function(req, res, next) {
    res.render('studentlogin', { msg: '' });
  });
 
router.post('/checkstudentlogin', function(req, res, next) {
    pool.query('select * from stu where stuid=? and pass=?',[req.body.stuid,req.body.pass],function(error,result){
     if(error)
     {res.render('studentlogin',{msg:'Server Error'})}
     else{
        if(result.length==0)
        res.render('studentlogin', { msg: 'Invalid StudentId/Password' });
        else
        req.session.STUDENT=result[0]
        res.render('dashboard/index', { data:req.session.STUDENT });
 

     }


    })
     });

     router.get('/logout', function(req, res, next) {
      req.session.destroy(function(err){
       if(err)
       { return console.log('Invalid Session')}
       res.render('dashboard/login.ejs', { msg: '' });
      })
      
    });
     module.exports=router;
     