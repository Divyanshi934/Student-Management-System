var express = require('express');
var router = express.Router();
var pool=require('./pool.js')
var upload=require('./multer')
/* GET home page. */
router.get('/searching', function(req, res, next) {
  res.render('search',{msg:''});
   });
router.get('/studentinterface', function(req, res, next) {
  if(!req.session.ADMIN)
 { res.render('adminlogin',{msg:''});}
 else
 {res.render('student',{msg:''});
 }

  //res.render('task',{msg:''
});
router.get('/studentinterfaces', function(req, res, next) {
  if(!req.session.STUDENT)
 { res.render('studentlogin',{msg:''});}
 else
 {res.render('student',{msg:''});
 }

  //res.render('task',{msg:''});
});

router.post('/displaytable',function(req,res,next){
  
    pool.query('select * from citycollege',function(error,result){
   
      if(error)
    { console.log(error) 
      res.render('displaytable',{data:'server record'});}
    else
    { 
      res.render('displaytable',{data:result});}
     })
    
    
  });


router.get('/displayall', function(req, res, next) {
  pool.query('select S.*,(select T.task from task T where T.taskid=S.task)as ttype,(select Sub.submitname from submit Sub where Sub.submitlistid=S.submitname)as tname from students S',function(error,result){
 if(error)
 {console.log(error)
   res.render('displayall',{data:'Server Error'})}
 else
 {res.render('displayall',{data:result})}
 
  })
 });

 router.get('/displaybyid', function(req, res, next) {
  pool.query('select S.*,(select T.task from task T where T.taskid=S.Task)as ttype,(select Sub.submitname from submit Sub where Sub.submitlistid=S.submitname)as tname from students S where S.studentid=?',[req.query.sid],function(error,result){
 if(error)
 { console.log(error)
  res.render('displaybyid',{data:'Server Error'})
}
 else
 { if(result.length==0)

   res.render('displaybyid',{data:'Record Not Found'})
  else
  res.render('displaybyid',{data:result[0]})
  
  }
  })
 });

 router.get('/displayall', function(req, res, next) {
  pool.query('select S.*,(select T.degree from degree T where T.degreeid=S.degree)as dtype,(select Sub.branchname from branch Sub where Sub.branchlistid=S.branchname)as dname from students S',function(error,result){
 if(error)
 {console.log(error)
   res.render('displayall',{data:'Server Error'})}
 else
 {res.render('displayall',{data:result})}
  })
 });

 router.get('/displaybyid', function(req, res, next) {
  pool.query('select S.*,(select T.degree from degree T where T.degreeid=S.degree)as dtype,(select Sub.branchname from branch Sub where Sub.branchlistid=S.branchname)as dname from students S where S.studentid=?',[req.query.sid],function(error,result){
 if(error)
 { console.log(error)
  res.render('displaybyid',{data:'Server Error'})
}
 else
 { if(result.length==0)

   res.render('displaybyid',{data:'Record Not Found'})
  else
  res.render('displaybyid',{data:result[0]})
  
  }
  })
 });
 
 

router.get('/studenteditdelete', function(req, res, next) {
  if(req.query.btn=='Edit')
  {
  pool.query('update students set name=?,degree=?,branchname=?,semester=?,joindate=?,internshipduration=?,gender=?,fathername=?,mobileno=?,emailid=?,dob=?,task=?,submitname=?  where studentid=?',[req.query.name,req.query.degree,req.query.branchname,req.query.semester,req.query.joindate,req.query.internshipduration,req.query.gender,req.query.fathername,req.query.emailid,req.query.mobileno,req.query.dob,req.query.task,req.query.submitname,req.query.studentid],function(error,result){
  
   if(error)
 { console.log(error)
  return res.redirect('/add/displayall')}
 else
 { return res.redirect('/add/displayall')}
  })
}
  else
  {
   pool.query('delete from  students  where studentid=?',[req.query.studentid],function(error,result){
  
     if(error)
   { console.log(error)
    return res.redirect('/add/displayall')}
   else
   { return res.redirect('/add/displayall')}
    })
   
 
  }
 
 }); 
 
 router.post('/editpicture',upload.single('profilepic'), function(req, res, next) {
  console.log(req.body)
  console.log(req.file)
 pool.query('update students set profilepic=? where studentid=?',[req.file.originalname,req.body.studentid],function(error,result){
 
  if(error)
  { console.log(error)
   return res.redirect('/add/displayall')}
  else
  { return res.redirect('/add/displayall')}
   })
  })


router.post('/studentsubmit',upload.single('profilepic'),function(req,res,next){
    console.log(req.body)
    console.log(req.file)
    pool.query('insert into students(name,degree,branchname,semester,joindate,internshipduration,gender,fathername,mobileno,emailid,dob,task,submitname,profilepic)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[req.body.name,req.body.degree,req.body.branchname,req.body.semester,req.body.joindate,req.body.internshipduration,req.body.gender,req.body.fathername,req.body.mobileno,req.body.emailid,req.body.dob,req.body.task,req.body.submitname,req.file.originalname],function(error,result){
      
      if(error)
      { console.log(error)
        
  //message='Fail to Submit'}

        res.render('student',{msg:'Fail to submit record'});}
        else
    { 
      //message='Record Submitted'}

    res.render('student',{msg:'Record Submitted'});}
    })
  });
  
    router.get('/fetchtask', function(req, res, next) {
      pool.query('select * from task',function(error,result){
      if(error)
      {
        return res.status(500).json([])
      }
      else
      {return res.status(200).json(result)}
    
    
      })
    });
    
    router.get('/fetchsubmit', function(req, res, next) {
      pool.query('select * from submit where taskid=?',[req.query.tid],function(error,result){
      if(error)
      {
        return res.status(500).json([])
      }
      else
      {return res.status(200).json(result)}
    
    
    
      })
          
  });

  router.get('/fetchdegree', function(req, res, next) {
    pool.query('select * from degree',function(error,result){
    if(error)
    {
      return res.status(500).json([])
    }
    else
    {return res.status(200).json(result)}
  
  
    })
  });
  
  router.get('/fetchbranch', function(req, res, next) {
    pool.query('select * from branch where degreeid=?',[req.query.bid],function(error,result){
    if(error)
    {
      return res.status(500).json([])
    }
    else
    {return res.status(200).json(result)}
  
  
  
    })
        
});
  
router.post('/ttable',upload.single('file'),function(req,res,next){
  console.log(req.body)
  console.log(req.file)
  pool.query('insert into ttable(file,assigndate,completedate,des)values(?,?,?,?)',[req.file.originalname,req.body.assigndate,req.body.completedate,req.body.des],function(error,result){
    
   if(error)
    { console.log(error)
      
//message='Fail to Submit'}

      res.render('student',{msg:'Fail to submit record'});}
      else
  { 
    //message='Record Submitted'}

  res.render('student',{msg:'Record Submitted'});}
    

   
    
   
  })
});

router.post('/marks',function(req,res,next){
  console.log(req.body)
  //console.log(req.file)
  pool.query('insert into marks(studid,mark,studname)values(?,?,?)',[req.body.studid,req.body.mark,req.body.studname],function(error,result){
    
   if(error)
    { console.log(error)
      
//message='Fail to Submit'}

      res.render('student',{msg:'Fail to submit record'});}
      else
  { 
    //message='Record Submitted'}

  res.render('student',{msg:'Record Submitted'});}
    

   
    
   
  })
});

router.get('/displayallJSON', function(req, res, next) {
  var q="select clgname from citycollege where cityname like '%"+req.query.txt+"%'"
  console.log(q) 
  pool.query(q,function(error,result){
  if(error)
  { console.log(error)
    res.status(500).json([])
  }
    else
  {res.status(200).json(result)}
})
});
  module.exports=router;